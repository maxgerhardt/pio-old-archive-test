__version__="4.0.1"
__copyright__="Copyright (c) 2001 - 2020 The SCons Foundation"
__developer__="bdbaddog"
__date__="2020-07-17 01:50:03"
__buildsys__="ProDog2020"
__revision__="c289977f8b34786ab6c334311e232886da7e8df1"
__build__="c289977f8b34786ab6c334311e232886da7e8df1"
# make sure compatibility is always in place
import SCons.compat # noqa